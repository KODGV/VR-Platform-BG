package com.vr.util;

public class StringUtil {
public static boolean isEmpty(String s)
{
	if(s==null||s.length()<=0)
	{
		return true;
	}
	else
	{
		return false;
	}
}
}
