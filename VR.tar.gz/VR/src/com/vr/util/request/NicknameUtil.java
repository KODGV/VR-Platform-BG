package com.vr.util.request;

public class NicknameUtil {
      private String NickName;

	public String getNickName() {
		return NickName;
	}

	public void setNickName(String nickName) {
		NickName = nickName;
	}
      
}
