package com.vr.util.request;

public class Statisticalanswer {
	private String onePercentage;
	private String twoPercentage;
	private String question;
	
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getOnePercentage() {
		return onePercentage;
	}
	public void setOnePercentage(String onePercentage) {
		this.onePercentage = onePercentage;
	}
	public String getTwoPercentage() {
		return twoPercentage;
	}
	public void setTwoPercentage(String twoPercentage) {
		this.twoPercentage = twoPercentage;
	}

	
}
