package com.vr.util.response;

public class ResponseData {

	protected int code;

	public ResponseData(int code) {
		this.code = code;
	}

	public ResponseData() {
		
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}
	
}
