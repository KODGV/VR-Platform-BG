package com.vr.view;

public class MessageResponseView {
	public interface Tag{}
}
