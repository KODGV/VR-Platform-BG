package com.vr.view;

public class QuestionView {
	public interface Tag{}

}
