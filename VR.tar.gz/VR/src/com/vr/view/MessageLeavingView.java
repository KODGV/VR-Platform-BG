package com.vr.view;

public class MessageLeavingView {
public interface Tag{}
}
