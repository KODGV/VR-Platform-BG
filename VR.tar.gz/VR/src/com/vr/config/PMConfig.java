package com.vr.config;

public interface PMConfig {
      public static final String SALT="pmhdfiudfhguiodfh0864984864gfds%@$%#2068";
}
