webpackJsonp([5],{

/***/ 482:
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(600)

var Component = __webpack_require__(185)(
  /* script */
  __webpack_require__(512),
  /* template */
  __webpack_require__(576),
  /* scopeId */
  "data-v-b769e66e",
  /* cssModules */
  null
)

module.exports = Component.exports


/***/ }),

/***/ 512:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__assets_hint_png__ = __webpack_require__(549);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__assets_hint_png___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__assets_hint_png__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
    data: function () {
        return {
            show1: true,
            show2: false,
            show3: false,
            show4: false,
            show5: false,
            // show:[true,false,false,false,false],
            pic_hint: __WEBPACK_IMPORTED_MODULE_0__assets_hint_png___default.a,
            activeName2: 'first',
            allowSubmit: true,
            hostURL: "/VR",
            datas: [{
                id: 1,
                brand: 1,
                salesmodel: 'name',
                productmodel: "name1",
                picLocation: "./static/img/img.jpg",
                //产品配置
                screentype: "22222", //屏幕类型
                monocularresolution: "222222", //单眼分辨率
                weight: 1, //重量
                cpu: 1,
                memory: 1,
                batteryCapacity: 1,
                //安全性
                workingtemperature: 1, //温升/发热
                bluerayirradiance: 1, //蓝光辐照度
                soundpressurelevel: 1, //声压
                maximumoutputvoltage: '110,  ≤150mv', //播放器的最大输出电压
                broadbandcharacteristicvoltageofearphone: 5555, //耳机的宽带特征电压
                boundarywarning: "222222222", //边界警示
                // 电磁兼容性
                radiationdisturbance: "./static/img/img.jpg", //辐射骚扰
                electrostaticdischarge: "./static/img/img.jpg", //静电放电
                //性能
                fieldangle: 1, //视场角
                refreshrate: 1, //刷新率
                systemdelay: 1, //系统延迟
                trackingmode: 1, //跟踪模式
                trackingrange: 1, //跟踪范围
                //20min视疲劳
                meanchangeofvisualacuity: 1, //视力变化均值
                ssqmean: 1, //SSQ均值
                cvsmean: 1 //CVS均值

            }, {
                id: 1,
                brand: 1,
                salesmodel: 'name',
                productmodel: "name1",
                picLocation: "./static/img/img.jpg",
                //产品配置
                screentype: "22222", //屏幕类型
                monocularresolution: "222222", //单眼分辨率
                weight: 1, //重量
                cpu: 1,
                memory: 1,
                batteryCapacity: 1,
                //安全性
                workingtemperature: 1, //温升/发热
                bluerayirradiance: 1, //蓝光辐照度
                soundpressurelevel: 1, //声压
                maximumoutputvoltage: 1000, //播放器的最大输出电压
                broadbandcharacteristicvoltageofearphone: 5555, //耳机的宽带特征电压
                boundarywarning: "222222222", //边界警示
                // 电磁兼容性
                radiationdisturbance: "./static/img/img.jpg", //辐射骚扰
                electrostaticdischarge: "./static/img/img.jpg", //静电放电
                //性能
                fieldangle: 1, //视场角
                refreshrate: 1, //刷新率
                systemdelay: 1, //系统延迟
                trackingmode: 1, //跟踪模式
                trackingrange: 1, //跟踪范围
                //20min视疲劳
                meanchangeofvisualacuity: 1, //视力变化均值
                ssqmean: 1, //SSQ均值
                cvsmean: 1 //CVS均值
            }, {
                id: 1,
                brand: 1,
                salesmodel: 'name',
                productmodel: "name1",
                picLocation: "./static/img/img.jpg",
                //产品配置
                screentype: "22222", //屏幕类型
                monocularresolution: "222222", //单眼分辨率
                weight: 1, //重量
                cpu: 1,
                memory: 1,
                batteryCapacity: 1,
                //安全性
                workingtemperature: 1, //温升/发热
                bluerayirradiance: 1, //蓝光辐照度
                soundpressurelevel: 1, //声压
                maximumoutputvoltage: 1000, //播放器的最大输出电压
                broadbandcharacteristicvoltageofearphone: 5555, //耳机的宽带特征电压
                boundarywarning: "222222222", //边界警示
                // 电磁兼容性
                radiationdisturbance: "./static/img/img.jpg", //辐射骚扰
                electrostaticdischarge: "./static/img/img.jpg", //静电放电
                //性能
                fieldangle: 1, //视场角
                refreshrate: 1, //刷新率
                systemdelay: 1, //系统延迟
                trackingmode: 1, //跟踪模式
                trackingrange: 1, //跟踪范围
                //20min视疲劳
                meanchangeofvisualacuity: 1, //视力变化均值
                ssqmean: 1, //SSQ均值
                cvsmean: 1 //CVS均值
            }] //return end
        };
    },
    methods: {
        codeParsing(code) {
            var msg = (Title, Message) => {
                this.$message({
                    title: Title,
                    message: Message,
                    type: 'error'
                });
            };
            switch (code) {
                case -1:
                    msg('系统错误', '未知错误，请上报管理员');
                    break;
                case 201:
                    msg('输入域错误', '验证码错误');
                    break;
                case 300:
                    msg('输入域错误', '邮箱或密码错误');
                    break;
                case 301:
                    msg('权限问题', '用户已禁用，请联系管理员');
                    break;
                case 302:
                    msg('权限问题', '用户未激活，请去邮箱激活用户');
                    break;
                case 303:
                    msg('注册问题', '邮箱已占用，请更改邮箱');
                    break;
                case 304:
                    msg('注册问题', '昵称已占用，请更改昵称');
                    break;
                case 400:
                    msg('权限问题', '用户未登录，请重新登录');
                    break;
                case 401:
                    msg('权限问题', '用户无权访问，请联系管理员');
                    break;
                case 402:
                    msg('操作错误', '删除错误,请刷新重试');
                    break;
                case 500:
                    msg('系统错误', '未知错误，请上报管理员');
                    break;
                case 600:
                    msg('TIME_OUT', '访问超时，请检查网络连接');
                    break;
                case 700:
                    msg('激活错误', '非法激活链接，请联系管理员');
                    break;
                case 800:
                    msg('激活错误', '用户已被激活，请直接登录');
                    break;
                default:
                    break;
            }
        },

        getData() {
            var self = this;
            var postId = {
                idList: []
            };
            var _url = "";
            // var str = localStorage.getItem('store');
            // var arr = str.split(',');
            // for(let i = 0;i<arr.length;i++){
            //     arr[i] = parseInt(arr[i]);
            // }
            var t = JSON.parse(localStorage.getItem('compare_data'));
            for (var i = 0; i < t.data.length; i++) postId.idList.push(t.data[i].id);
            var kind = localStorage.getItem('kind');
            if (kind == "ivr") {
                _url = '/ivrCompare';
            } else if (kind == "svr") {
                _url = '/svrCompare';
            } else if (kind == "evr") {
                _url = '/evrCompare';
            }
            self.datas = {};
            self.$axios({
                url: _url,
                // url:'./static/ivr.json',
                method: 'post',
                data: postId,
                baseURL: self.hostURL
            }).then(response => {
                console.log(response.data);
                self.datas = response.data.data.payload;
            }).catch(error => {
                console.log(error);
            });
        },
        // getInfo(id){
        //     for(var i=0;i<5;i++)
        //     {
        //         if(this.show[i]==true)
        //         {

        //             this.show[i]=false;
        //         }

        //     }
        //     this.show[id]=true;
        //     for(var i=0;i<5;i++)
        //     {
        //         // if(this.show[i]==true)
        //         // {

        //         //     this.show[i]=false;
        //         // }
        //         console.log(this.show[i]);
        //     }
        // },
        parameter() {

            this.show1 = true;this.show2 = false;this.show3 = false;this.show4 = false;this.show5 = false;
        },
        security() {
            this.show1 = false;this.show2 = true;this.show3 = false;this.show4 = false;this.show5 = false;
        },
        compatibility() {
            this.show1 = false;this.show2 = false;this.show3 = true;this.show4 = false;this.show5 = false;
        },
        properties() {
            this.show1 = false;this.show2 = false;this.show3 = false;this.show4 = true;this.show5 = false;
        },
        asthenopia() {
            this.show1 = false;this.show2 = false;this.show3 = false;this.show4 = false;this.show5 = true;
        }

    },

    mounted() {
        var self = this;
        self.getData();
    }
});

/***/ }),

/***/ 547:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(82)(undefined);
// imports


// module
exports.push([module.i, ".crumbs[data-v-b769e66e]{text-decoration:none}.bread[data-v-b769e66e]{font-size:16px}.form-box[data-v-b769e66e]{width:300px;margin-top:50px;margin-left:0;box-shadow:0 0 8px 0 rgba(232,237,250,.9),0 2px 4px 0 rgba(232,237,250,.9);padding:50px 50px 50px 10px}.submit-btn[data-v-b769e66e]{width:220px;margin-left:80px}.submit-btn button[data-v-b769e66e]{width:100%}.compare-box[data-v-b769e66e]{padding:28px;width:880px;border:1px solid #e1e1e1;box-shadow:0 0 2px rgba(0,0,0,.1);margin-left:200px}.compare-table[data-v-b769e66e]{border-collapse:collapse;width:800px;margin-left:40px}.compare-table .cate-title[data-v-b769e66e]{text-align:left;height:35px;border:1px solid #e6e6e6;padding-left:10px;background:#fafafa}.compare-table td[data-v-b769e66e]{width:218px;padding:8px 0;zoom:1;text-align:center;word-wrap:break-word;word-break:break-all;border:1px solid #e6e6e6}.cate-title strong[data-v-b769e66e]{position:relative;display:block;padding-left:17px;height:20px;font:16px/20px Microsoft YaHei,arial;background-position:-87px 2px;color:#333;font-weight:700}.compare-table th[data-v-b769e66e]{padding:8px 10px;width:102px;border:1px solid #e6e6e6;background:#fafafa;font-weight:400;text-align:right;line-height:18px;font-size:14px}.param-content[data-v-b769e66e]{width:200px;white-space:nowrap}.param-content img[data-v-b769e66e]{width:100%;margin-left:7px}.main-left[data-v-b769e66e]{text-align:center;width:200px;float:left}", ""]);

// exports


/***/ }),

/***/ 549:
/***/ (function(module, exports) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAHjklEQVR4nO3d223rOBCAYZeQElRCSlAJKcElpAR34BJcgp6o4ZtLcAkuISXsPoQKslmRlGyRM6L/DzBwgLM4or0acTi86HAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAahiG4c059z6O44dz7uS9P4vIxXs/iMhVRK7hzxcRuTjnTiJyFJFeu+3A5kIwfIYb/i4i/zz78d4PzrmTc+5d+/sBq4lIH3qH2xYBsSBgzvQwMC2kTtWCIhIoN+/9Wfu3AH4Mw/AWxgibpE9bfcZx/NT+bfDiRKR/sse4SxiU/x6Yy38H7c8E3l1Ejtq/E17MI4Hhvf8KN/3ROfc+DMPbymt24zh+hOD5Wpt6ESgoLqRTl5VBcX4kIHKmMvHKHuYqIt2W7QAOh8N3uXbJzei9/6pdghWRPpSSFwWtUPHClkJKlUxrwt9ftJ/QoVdhEI86xnH8XJDzXy1N2i1NBSkJ42ELbzJTgfFXSAuz30G7ndiZYRjeQsWpiRQlNz7x3t8sBzoMCT3HNTXWGMfxQ7udaznn3lOpovf+a+tKGxqUSknCfEKv3cZHhZ4xNX9DuoW4TCpybeUJm0ofvfeDdvtgkHyvp4pWe1oJjklm8H7Ubh8MSeXn3vtba8ExyRQieu32wYAwKL9HbpJ7q8ExiY1JwooAKluvLpZqvMqSjDBwj1W37trtgyIR6RPzHLsr5T4qTCi+/O+AP2LzHTWXYEyHOEwHOYQl7X3t9CZcd7YnrdkOGBG7IWrMBfzahXhdsAhycM6daoyFEoP2Y+lrw5jEhFlf8rryxPbc0j1bCFx6kVcXmxAsOUm2ZH3Xws+9ZPoVK1o4506lrglDYmXdkmXNBUs8Hvn0pdoa60WE3Yjti20oKpW+bNhzVAvoxKarS4nrwRCZqVyVfDou2Qo7HegQ9q9Px5H+r51z6VaJNqd62RLXgxGxen+p3kNEugW7ES+xClVYApNLzY6F2h5bm1bkejAgkTr0la+36mbLBEnJXoQ065XUThtSN/aaipmIdJlA60q0P/Z7tb4+7SVppFdb3tSZXqQv8R1q97hQFBssl1prlFrf9Mh8Sxi4z/57pfbHx9Is5kQaNFdqLZkuJJayPHSDidIGp9ppKZRE/kcX3V7qvT//rmKFP6/eupvZs1J0xW2s52Ic0pBYqlBrKbeIdM+cz5uaSyk9wx3rCdlM1ZDEeKDXblvOOI4fmeN6ivaCiYfLbs4FQ4bEJ7067baliMhxwURjX7odc21goN6QSIpiejvpkjOBa23skvnlORwP1IpIBcjsIWkLT2ivdk7X3O9HgDRkTwGyJDhqH0UUqWSZ/P3wgMhyc3NriiwGx+EwHyDe+1vNNqCguRzaWoCkJhY10qrfIoFregyHFawHSOZsqp+cX2tybo9FDqwQWWZiZpC5ILWK7hnRah8pVkOsV2Eyy+LVD85mDNI4y1WY1KpfMXI28J6qgHhA5AloYkWqJI4/tTJbvZcqIB4UqxAZeTpH30ti5VxcmV8JzRtyWxF7SltYkZoKEAvtS+xNP2q3DRuxvCI1FSBiYDHlnldCY4XIPIN6Hi0i3XSq+9+PhRQwUYLutNuGDUVKvSYG6pbJ/EpeSrytSaQyvXbbrKp9EgwUcRDaerVPgoGyuXGIhTQrVNmml+ncLcyeHw7JF+p02m1DAYmzpTqtNsV2Dmq/ZTa2gNLSEh1sLJZTa5V7JX+4tdqK2djkKulV48TQebNLXo2g0YvEXvjDubwvIJZmaVRmlrxYR6N3SwQuBY3WZTYndTXbkjpvVyul0XhFHYyx8oSUxEre6aasHbS1X1EHo+aekhq9iCRetVZ7uXuicsXY49VIZGa9dhlz7iWf3vuvcRw/LZxeohGoMCLRixwV2tKHoD1q5PoSP+bUxK5GKMgctdNrt6+W8LLQ2cKFhS0BUBQbA2gMkDXE5jzoPXA4HLKz2U2f/TQ3/vnzgOi12wgDMuXWZk/vyMzDHLXbB0NS45EW5wAyb61q7vtiA5J+UWYTPUlIq1I9h+opjjAuNXEXBrOddhsflRpzTN+P4EBSpqqz2zVJYal/bN5nt98LCkSkS91MexvEikifeRHoF/s8sEpY1RpNt6Z83XLKNY03MsGx67QRypYsSbdW9VkSGFPhgTEHnrZk55+FQBmG4S20NZcemnitAhoimb0bf/L5qitxQ2B8pIoLv9u3p/ETdiQs6svehL9TmLABqdu6LfJ9ZOmn9/62IJX6GW8wGEdx8r0sPZvG/L05w3imf+SaoWjQO+dOK4NUbX8JXlzsTKulN22YtLt478/OuZNz7hT+zXMIpot8V9JWBSOBAVOWDuJrfULwMQiHHStKq0UDQ0QuzIjDtLAy+FIxKK4icqTHwO6M4/gRKlnXDdOnnwE/QYGmSHijVAiaaRB+DZWpu3yf7n4Ln8F7P4T/9uiceycgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUMW/GOhioDnNWiQAAAAASUVORK5CYII="

/***/ }),

/***/ 576:
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', [_c('div', {
    staticClass: "crumbs"
  }, [_c('el-breadcrumb', {
    attrs: {
      "separator": "/"
    }
  }, [_c('el-breadcrumb-item', [_c('i', {
    staticClass: "el-icon-date"
  }), _vm._v("产品中心")]), _vm._v(" "), _c('el-breadcrumb-item', [_vm._v("产品对比")])], 1)], 1), _vm._v(" "), _c('div', {
    staticClass: "main-left"
  }, [_c('el-menu', {
    staticClass: "el-menu-vertical-demo",
    attrs: {
      "default-active": "#/1",
      "router": true,
      "theme": "light"
    }
  }, [_c('el-menu-item', {
    staticClass: "menu-item",
    class: {
      'isActive': _vm.active
    },
    attrs: {
      "index": "#/1"
    },
    on: {
      "click": function($event) {
        _vm.parameter()
      }
    }
  }, [_vm._v("产品参数")]), _vm._v(" "), _c('el-menu-item', {
    staticClass: "menu-item",
    class: {
      'isActive': !_vm.active
    },
    attrs: {
      "index": "#/2"
    },
    on: {
      "click": function($event) {
        _vm.security()
      }
    }
  }, [_vm._v("安全性")]), _vm._v(" "), _c('el-menu-item', {
    staticClass: "menu-item",
    class: {
      'isActive': !_vm.active
    },
    attrs: {
      "index": "#/3"
    },
    on: {
      "click": function($event) {
        _vm.compatibility()
      }
    }
  }, [_vm._v("电磁兼容性")]), _vm._v(" "), _c('el-menu-item', {
    staticClass: "menu-item",
    class: {
      'isActive': !_vm.active
    },
    attrs: {
      "index": "#/4"
    },
    on: {
      "click": function($event) {
        _vm.properties()
      }
    }
  }, [_vm._v("性能")]), _vm._v(" "), _c('el-menu-item', {
    staticClass: "menu-item",
    class: {
      'isActive': !_vm.active
    },
    attrs: {
      "index": "#/5"
    },
    on: {
      "click": function($event) {
        _vm.asthenopia()
      }
    }
  }, [_vm._v("视疲劳")])], 1)], 1), _vm._v(" "), _c('div', {
    staticClass: "compare-box"
  }, [(_vm.show1) ? _c('table', {
    staticClass: "compare-table"
  }, [_c('tbody', [_c('tr', {
    staticClass: "cate-tr"
  }, [_vm._m(0), _vm._v(" "), _vm._l((_vm.datas), function(data) {
    return _c('td', [_c('div', {
      staticClass: "param-content"
    }, [_c('img', {
      attrs: {
        "src": data.picLocation
      }
    })])])
  })], 2), _vm._v(" "), _c('tr', {
    staticClass: "param-list"
  }, [_vm._m(1), _vm._v(" "), _vm._l((_vm.datas), function(data) {
    return _c('td', [_c('div', {
      staticClass: "param-content"
    }, [_c('span', [_vm._v(_vm._s(data.brand))])])])
  })], 2), _vm._v(" "), _c('tr', {
    staticClass: "param-list"
  }, [_vm._m(2), _vm._v(" "), _vm._l((_vm.datas), function(data) {
    return _c('td', [_c('div', {
      staticClass: "param-content"
    }, [_c('span', [_vm._v(_vm._s(data.salesmodel))])])])
  })], 2), _vm._v(" "), _c('tr', {
    staticClass: "param-list"
  }, [_vm._m(3), _vm._v(" "), _vm._l((_vm.datas), function(data) {
    return _c('td', [_c('div', {
      staticClass: "param-content"
    }, [_c('span', [_vm._v(_vm._s(data.productmodel))])])])
  })], 2), _vm._v(" "), _c('tr', {
    staticClass: "param-list"
  }, [_vm._m(4), _vm._v(" "), _vm._l((_vm.datas), function(data) {
    return _c('td', [_c('div', {
      staticClass: "param-content"
    }, [_c('span', [_vm._v(_vm._s(data.screentype))])])])
  })], 2), _vm._v(" "), _c('tr', {
    staticClass: "param-list"
  }, [_vm._m(5), _vm._v(" "), _vm._l((_vm.datas), function(data) {
    return _c('td', [_c('div', {
      staticClass: "param-content"
    }, [_c('span', [_vm._v(_vm._s(data.monocularresolution))])])])
  })], 2), _vm._v(" "), _c('tr', {
    staticClass: "param-list"
  }, [_vm._m(6), _vm._v(" "), _vm._l((_vm.datas), function(data) {
    return _c('td', [_c('div', {
      staticClass: "param-content"
    }, [_c('span', [_vm._v(_vm._s(data.weight))])])])
  })], 2), _vm._v(" "), _c('tr', {
    staticClass: "param-list"
  }, [_vm._m(7), _vm._v(" "), _vm._l((_vm.datas), function(data) {
    return _c('td', [_c('div', {
      staticClass: "param-content"
    }, [_c('span', [_vm._v(_vm._s(data.cpu))])])])
  })], 2), _vm._v(" "), _c('tr', {
    staticClass: "param-list"
  }, [_vm._m(8), _vm._v(" "), _vm._l((_vm.datas), function(data) {
    return _c('td', [_c('div', {
      staticClass: "param-content"
    }, [_c('span', [_vm._v(_vm._s(data.memory))])])])
  })], 2), _vm._v(" "), _c('tr', {
    staticClass: "param-list"
  }, [_vm._m(9), _vm._v(" "), _vm._l((_vm.datas), function(data) {
    return _c('td', [_c('div', {
      staticClass: "param-content"
    }, [_c('span', [_vm._v(_vm._s(data.batteryCapacity))])])])
  })], 2)])]) : _vm._e(), _vm._v(" "), (_vm.show2) ? _c('table', {
    staticClass: "compare-table"
  }, [_c('tbody', [_c('tr', {
    staticClass: "cate-tr"
  }, [_vm._m(10), _vm._v(" "), _vm._l((_vm.datas), function(data) {
    return _c('td', [_c('div', {
      staticClass: "param-content"
    }, [_c('img', {
      attrs: {
        "src": data.picLocation
      }
    })])])
  })], 2), _vm._v(" "), _c('tr', {
    staticClass: "param-list"
  }, [_c('th', {
    staticClass: "cate-title"
  }, [_c('strong', [_vm._v("\n                        工作温度(℃)"), _c('img', {
    staticStyle: {
      "{width": "25px",
      "height": "25px"
    },
    attrs: {
      "src": _vm.pic_hint,
      "title": "工作温度小于55℃表示正常"
    }
  })]), _vm._v(" "), _c('br')]), _vm._v(" "), _vm._l((_vm.datas), function(data) {
    return _c('td', [_c('div', {
      staticClass: "param-content"
    }, [_c('span', {
      staticClass: "safety"
    }, [_vm._v(_vm._s(data.workingtemperature))])])])
  })], 2), _vm._v(" "), _c('tr', {
    staticClass: "param-list"
  }, [_c('th', {
    staticClass: "cate-title"
  }, [_c('strong', [_vm._v("\n                        蓝光辐照度(W·m^－2·sr^－1)"), _c('img', {
    staticStyle: {
      "{width": "25px",
      "height": "25px"
    },
    attrs: {
      "src": _vm.pic_hint,
      "title": "声压小于100dB表示正常"
    }
  })]), _vm._v(" "), _c('br'), _vm._v(" "), _c('br')]), _vm._v(" "), _vm._l((_vm.datas), function(data) {
    return _c('td', [_c('div', {
      staticClass: "param-content"
    }, [_c('span', {
      staticClass: "safety"
    }, [_vm._v(_vm._s(data.bluerayirradiance))])])])
  })], 2), _vm._v(" "), _c('tr', {
    staticClass: "param-list"
  }, [_c('th', {
    staticClass: "cate-title"
  }, [_c('strong', [_vm._v("\n                        声压(dB(A))"), _c('img', {
    staticStyle: {
      "{width": "25px",
      "height": "25px"
    },
    attrs: {
      "src": _vm.pic_hint,
      "title": "声压小于100dB表示正常"
    }
  })])]), _vm._v(" "), _vm._l((_vm.datas), function(data) {
    return _c('td', [_c('div', {
      staticClass: "param-content"
    }, [_c('span', {
      staticClass: "safety"
    }, [_vm._v(_vm._s(data.soundpressurelevel))])])])
  })], 2), _vm._v(" "), _c('tr', {
    staticClass: "param-list"
  }, [_c('th', {
    staticClass: "cate-title"
  }, [_c('strong', [_vm._v("\n                        播放器最大输出电压(mV)"), _c('img', {
    staticStyle: {
      "{width": "25px",
      "height": "25px"
    },
    attrs: {
      "src": _vm.pic_hint,
      "title": "最大输出电压小于150mV表示正常"
    }
  })]), _vm._v(" "), _c('br')]), _vm._v(" "), _vm._l((_vm.datas), function(data) {
    return _c('td', [_c('div', {
      staticClass: "param-content"
    }, [_c('span', {
      staticClass: "safety"
    }, [_vm._v(_vm._s(data.maximumoutputvoltage))])])])
  })], 2), _vm._v(" "), _c('tr', {
    staticClass: "param-list"
  }, [_c('th', {
    staticClass: "cate-title"
  }, [_c('strong', [_vm._v("\n                        耳机的宽带特征电压(mV)"), _c('img', {
    staticStyle: {
      "{width": "25px",
      "height": "25px"
    },
    attrs: {
      "src": _vm.pic_hint,
      "title": "特征电压大于75mV表示正常"
    }
  })]), _vm._v(" "), _c('br')]), _vm._v(" "), _vm._l((_vm.datas), function(data) {
    return _c('td', [_c('div', {
      staticClass: "param-content"
    }, [_c('span', {
      staticClass: "safety"
    }, [_vm._v(_vm._s(data.broadbandcharacteristicvoltageofearphone))])])])
  })], 2), _vm._v(" "), _c('tr', {
    staticClass: "param-list"
  }, [_vm._m(11), _vm._v(" "), _vm._l((_vm.datas), function(data) {
    return _c('td', [_c('div', {
      staticClass: "param-content"
    }, [_c('span', [_vm._v(_vm._s(data.boundarywarning))])])])
  })], 2)])]) : _vm._e(), _vm._v(" "), (_vm.show3) ? _c('table', {
    staticClass: "compare-table"
  }, [_c('tbody', [_c('tr', {
    staticClass: "cate-tr"
  }, [_vm._m(12), _vm._v(" "), _vm._l((_vm.datas), function(data) {
    return _c('td', [_c('div', {
      staticClass: "param-content"
    }, [_c('img', {
      attrs: {
        "src": data.picLocation
      }
    })])])
  })], 2), _vm._v(" "), _c('tr', {
    staticClass: "param-list"
  }, [_vm._m(13), _vm._v(" "), _vm._l((_vm.datas), function(data) {
    return _c('td', [_c('div', {
      staticClass: "param-content"
    }, [_c('img', {
      attrs: {
        "src": data.radiationdisturbance
      }
    })])])
  })], 2), _vm._v(" "), _c('tr', {
    staticClass: "param-list"
  }, [_vm._m(14), _vm._v(" "), _vm._l((_vm.datas), function(data) {
    return _c('td', [_c('div', {
      staticClass: "param-content"
    }, [_c('img', {
      attrs: {
        "src": data.electrostaticdischarge
      }
    })])])
  })], 2)])]) : _vm._e(), _vm._v(" "), (_vm.show4) ? _c('table', {
    staticClass: "compare-table"
  }, [_c('tbody', [_c('tr', {
    staticClass: "cate-tr"
  }, [_vm._m(15), _vm._v(" "), _vm._l((_vm.datas), function(data) {
    return _c('td', [_c('div', {
      staticClass: "param-content"
    }, [_c('img', {
      attrs: {
        "src": data.picLocation
      }
    })])])
  })], 2), _vm._v(" "), _c('tr', {
    staticClass: "param-list"
  }, [_c('th', {
    staticClass: "cate-title"
  }, [_c('strong', [_vm._v("\n                        视场角(°)"), _c('img', {
    staticStyle: {
      "{width": "25px",
      "height": "25px"
    },
    attrs: {
      "src": _vm.pic_hint,
      "title": "级别划分：一级：000-010，二级：010-020，三级：020-030"
    }
  })])]), _vm._v(" "), _vm._l((_vm.datas), function(data) {
    return _c('td', [_c('div', {
      staticClass: "param-content"
    }, [_c('span', {
      staticClass: "safety"
    }, [_vm._v(_vm._s(data.fieldangle))])])])
  })], 2), _vm._v(" "), _c('tr', {
    staticClass: "param-list"
  }, [_c('th', {
    staticClass: "cate-title"
  }, [_c('strong', [_vm._v("\n                        刷新率(Hz)"), _c('img', {
    staticStyle: {
      "{width": "25px",
      "height": "25px"
    },
    attrs: {
      "src": _vm.pic_hint,
      "title": "级别划分：一级：000-010，二级：010-020，三级：020-030"
    }
  })])]), _vm._v(" "), _vm._l((_vm.datas), function(data) {
    return _c('td', [_c('div', {
      staticClass: "param-content"
    }, [_c('span', {
      staticClass: "safety"
    }, [_vm._v(_vm._s(data.refreshrate))])])])
  })], 2), _vm._v(" "), _c('tr', {
    staticClass: "param-list"
  }, [_c('th', {
    staticClass: "cate-title"
  }, [_c('strong', [_vm._v("\n                        系统延迟(ms)"), _c('img', {
    staticStyle: {
      "{width": "25px",
      "height": "25px"
    },
    attrs: {
      "src": _vm.pic_hint,
      "title": "级别划分：一级：000-010，二级：010-020，三级：020-030"
    }
  })])]), _vm._v(" "), _vm._l((_vm.datas), function(data) {
    return _c('td', [_c('div', {
      staticClass: "param-content"
    }, [_c('span', {
      staticClass: "safety"
    }, [_vm._v(_vm._s(data.systemdelay))])])])
  })], 2), _vm._v(" "), _c('tr', {
    staticClass: "param-list"
  }, [_vm._m(16), _vm._v(" "), _vm._l((_vm.datas), function(data) {
    return _c('td', [_c('div', {
      staticClass: "param-content"
    }, [_c('span', [_vm._v(_vm._s(data.trackingmode))])])])
  })], 2), _vm._v(" "), _c('tr', {
    staticClass: "param-list"
  }, [_vm._m(17), _vm._v(" "), _vm._l((_vm.datas), function(data) {
    return _c('td', [_c('div', {
      staticClass: "param-content"
    }, [_c('span', [_vm._v(_vm._s(data.trackingrange))])])])
  })], 2)])]) : _vm._e(), _vm._v(" "), (_vm.show5) ? _c('table', {
    staticClass: "compare-table"
  }, [_c('tbody', [_c('tr', {
    staticClass: "cate-tr"
  }, [_vm._m(18), _vm._v(" "), _vm._l((_vm.datas), function(data) {
    return _c('td', [_c('div', {
      staticClass: "param-content"
    }, [_c('img', {
      attrs: {
        "src": data.picLocation
      }
    })])])
  })], 2), _vm._v(" "), _c('tr', {
    staticClass: "param-list"
  }, [_c('th', {
    staticClass: "cate-title"
  }, [_c('strong', [_vm._v("\n                        视力变化均值"), _c('img', {
    staticStyle: {
      "{width": "25px",
      "height": "25px"
    },
    attrs: {
      "src": _vm.pic_hint,
      "title": "级别划分：一级：000-010，二级：010-020，三级：020-030"
    }
  })])]), _vm._v(" "), _vm._l((_vm.datas), function(data) {
    return _c('td', [_c('div', {
      staticClass: "param-content"
    }, [_c('span', {
      staticClass: "safety"
    }, [_vm._v(_vm._s(data.meanchangeofvisualacuity))])])])
  })], 2), _vm._v(" "), _c('tr', {
    staticClass: "param-list"
  }, [_c('th', {
    staticClass: "cate-title"
  }, [_c('strong', [_vm._v("\n                        SSQ均值"), _c('img', {
    staticStyle: {
      "{width": "25px",
      "height": "25px"
    },
    attrs: {
      "src": _vm.pic_hint,
      "title": "级别划分：一级：000-010，二级：010-020，三级：020-030"
    }
  })])]), _vm._v(" "), _vm._l((_vm.datas), function(data) {
    return _c('td', [_c('div', {
      staticClass: "param-content"
    }, [_c('span', {
      staticClass: "safety"
    }, [_vm._v(_vm._s(data.ssqmean))])])])
  })], 2), _vm._v(" "), _c('tr', {
    staticClass: "param-list"
  }, [_c('th', {
    staticClass: "cate-title"
  }, [_c('strong', [_vm._v("\n                        CVS均值"), _c('img', {
    staticStyle: {
      "{width": "25px",
      "height": "25px"
    },
    attrs: {
      "src": _vm.pic_hint,
      "title": "级别划分：一级：000-010，二级：010-020，三级：020-030"
    }
  })])]), _vm._v(" "), _vm._l((_vm.datas), function(data) {
    return _c('td', [_c('div', {
      staticClass: "param-content"
    }, [_c('span', {
      staticClass: "safety"
    }, [_vm._v(_vm._s(data.cvsmean))])])])
  })], 2)])]) : _vm._e()])])
},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('td', {
    staticClass: "cate-title"
  }, [_c('strong', [_vm._v("产品外观")])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('th', {
    staticClass: "cate-title"
  }, [_c('strong', [_vm._v("\n                        品牌\n                    ")])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('th', {
    staticClass: "cate-title"
  }, [_c('strong', [_vm._v("\n                        销售型号\n                    ")])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('th', {
    staticClass: "cate-title"
  }, [_c('strong', [_vm._v("\n                        产品型号\n                    ")])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('th', {
    staticClass: "cate-title"
  }, [_c('strong', [_vm._v("\n                        屏幕类型\n                    ")])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('th', {
    staticClass: "cate-title"
  }, [_c('strong', [_vm._v("\n                        单眼分辨率\n                    ")])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('th', {
    staticClass: "cate-title"
  }, [_c('strong', [_vm._v("\n                        重量(kg)\n                    ")])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('th', {
    staticClass: "cate-title"
  }, [_c('strong', [_vm._v("\n                       CPU(GHz)\n                    ")])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('th', {
    staticClass: "cate-title"
  }, [_c('strong', [_vm._v("\n                        内存(GB)\n                    ")])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('th', {
    staticClass: "cate-title"
  }, [_c('strong', [_vm._v("\n                        电池容量（mAh)\n                    ")])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('td', {
    staticClass: "cate-title"
  }, [_c('strong', [_vm._v("产品外观")])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('th', {
    staticClass: "cate-title"
  }, [_c('strong', [_vm._v("\n                        边界警示\n                    ")])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('td', {
    staticClass: "cate-title"
  }, [_c('strong', [_vm._v("产品外观")])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('th', {
    staticClass: "cate-title"
  }, [_c('strong', [_vm._v("\n                        辐射骚扰\n                    ")])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('th', {
    staticClass: "cate-title"
  }, [_c('strong', [_vm._v("\n                        静电放电\n                     ")])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('td', {
    staticClass: "cate-title"
  }, [_c('strong', [_vm._v("产品外观")])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('th', {
    staticClass: "cate-title"
  }, [_c('strong', [_vm._v("\n                        跟踪模式(m)\n                    ")])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('th', {
    staticClass: "cate-title"
  }, [_c('strong', [_vm._v("\n                        跟踪范围\n                    ")])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('td', {
    staticClass: "cate-title"
  }, [_c('strong', [_vm._v("产品外观")])])
}]}

/***/ }),

/***/ 600:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(547);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(186)("25e469e0", content, true);

/***/ })

});